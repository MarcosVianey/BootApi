import { useState } from 'react';
import { BiSearch } from 'react-icons/bi'
import classes from './SearchBar.module.css';
import axios from "axios";

const SearchBar = (props) => {
  
  const [searchTerm, setSearchTerm] = useState('');
  const [productsList, setProductsList] = useState([]);
  const iconStyle = {fontSize: "50px"};

  const api = axios.create({
    baseURL: "http://localhost:44327",
  });

  const handleClick = (event)=>{
    event.preventDefault();
    let response;
    api
      .get("/store?termo="+searchTerm)
      .then((response) => setProductsList(response.data))
      .catch((err) => {
      console.error("ops! ocorreu um erro" + err);
    });

    console.log(productsList);
  };

  const handleChange = (event)=>{
    setSearchTerm(event.target.value);
  };

  return (
    <form className={classes.button}>
      <input 
        value={searchTerm}
        onChange={handleChange}
        className={classes.search} 
        placeholder="Pesquisar" 
        type="text" 
        name="pesquisar"
      />
      <button className={classes.badge} onClick={handleClick}><BiSearch style={{iconStyle}}/></button>
    </form>
  );
};

export default SearchBar;
